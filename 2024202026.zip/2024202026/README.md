For the first question I used grep command to filter the strings having POST and then further filtering the strings having 404

For the second question :  1. Check if the file exists
                           2. Calculate the total power level by summing the fourth field of each line in the file
                           3. Display the total power level