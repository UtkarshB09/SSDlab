#!/bin/bash
sourcefile='access.log'
grep 'POST' "$sourcefile" | grep '404'