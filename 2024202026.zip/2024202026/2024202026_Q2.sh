#!/bin/bash

# Check if the file exists
if [ ! -f power_levels.txt ]; then
    echo "File power_levels.txt not found!"
    exit 1
fi

# Calculate the total power level by summing the fourth field of each line in the file
pow_sum=$(awk -F, '{sum += $4} END {print sum}' power_levels.txt)

# Display the total power level
echo "The total power level of all seniors sums up to : $pow_sum"